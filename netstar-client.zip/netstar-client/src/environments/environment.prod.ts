export const environment = {
  production: true,
  AUTH_API_URL: 'https://netstar-apigateway.azurewebsites.net/api/auth',
  MOVIE_API_URL: 'https://netstar-apigateway.azurewebsites.net/api/movies'
};
