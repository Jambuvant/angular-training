import { Component, OnInit } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { MoviesService } from '../../services/movies.service';
import { Movie } from '../../models/movie';

@Component({
  selector: 'app-movies-list',
  templateUrl: './movies-list.component.html',
  styleUrls: ['./movies-list.component.css']
})
export class MoviesListComponent implements OnInit {

  movies: Observable<Movie[]>;
  
  constructor(private moviesSvc: MoviesService) { 
    this.movies = this.moviesSvc.getMovies()
  }

  ngOnInit(): void {
  }

}
