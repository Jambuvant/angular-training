import { Component, OnInit } from '@angular/core';
import { MoviesService } from '../../services/movies.service';
import { Movie } from '../../models/movie';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-movie-detail',
  templateUrl: './movie-detail.component.html',
  styleUrls: ['./movie-detail.component.css']
})
export class MovieDetailComponent implements OnInit {

  movie: Movie

  constructor(/*private movieSvc: MoviesService,*/ private route: ActivatedRoute) { }
  
  ngOnInit(): void {
    // let id = this.route.snapshot.params['id']
    // this.movieSvc.getMovieById(id)
    // .subscribe({
    //   next: (data)=> this.movie = data,
    //   error: (err)=> console.error(err)
      
    // })
    this.movie = this.route.snapshot.data['movie']
  }

}
