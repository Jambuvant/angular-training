import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  movies: any[] = [
    {
      title: 'Avenger',
      releaseYear: 2020,
      director: 'Abc'
    },
    {
      title: 'Joker',
      releaseYear: 2021,
      director: 'Abcd'
    },
    {
      title: 'Antman',
      releaseYear: 2022,
      director: 'Abc'
    },
    {
      title: 'Avenger 2',
      releaseYear: 2020,
      director: 'Abc'
    },
    {
      title: 'Dark',
      releaseYear: 2020,
      director: 'Abcdd'
    },
  ]
  constructor() { }

  ngOnInit(): void {
  }

}
