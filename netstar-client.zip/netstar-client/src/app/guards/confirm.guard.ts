import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanDeactivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { RegisterComponent } from '../auth/components/register/register.component';

@Injectable({
  providedIn: 'root'
})
export class ConfirmGuard implements CanDeactivate<RegisterComponent> {

  // canDeactivate(
  //   component: any,
  //   currentRoute: ActivatedRouteSnapshot,
  //   currentState: RouterStateSnapshot,
  //   nextState?: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
  //     let result = confirm('Are you sure to leave this page?');
  //     return result;
  // }
  
  canDeactivate(component: RegisterComponent, currentRoute: ActivatedRouteSnapshot, currentState: RouterStateSnapshot, nextState?: RouterStateSnapshot | undefined): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
    if (!component.isRegisterSuccess) {
      let result = confirm('Are you sure to leave this page?');
      return result
    }
    
    return true
  }
  
}
