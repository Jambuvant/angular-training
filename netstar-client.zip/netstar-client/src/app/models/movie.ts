export interface Movie {
    id: number;
    title: string,
    actors: string,
    directors: string,
    description: string,
    releaseYear: number,
    genres: string,
    thumbnailUrl: string,
    shortVideoUrl: string,
    status: string    
}