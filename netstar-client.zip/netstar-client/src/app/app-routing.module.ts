import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { MoviesListComponent } from './components/movies-list/movies-list.component';
import { MovieDetailComponent } from './components/movie-detail/movie-detail.component';
import { resolve } from 'dns';
import { MovieDataResolver } from './resolvers/movie-data.resolver';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    pathMatch: 'full'
  },
  {
    path: 'about',
    component: AboutComponent
  },
  {
    path: 'auth',
    loadChildren: () => import('./auth/auth.module').then(m=>m.AuthModule) 
  },
  {
    path: 'movies',
    component: MoviesListComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'movies/detail/:id',
    component: MovieDetailComponent,
    resolve: {
      movie: MovieDataResolver
    }
  },
  {
    path: '**',  // invalid urls
    redirectTo: ''
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
