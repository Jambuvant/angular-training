import { Input, Directive, ElementRef, HostListener, HostBinding } from '@angular/core';

@Directive({
  selector: '[highlight]'
})
export class HighlightDirective {

  @Input() highlight:string='yellow'

  constructor(private el: ElementRef) { }

  @HostListener('mouseenter') 
  public applyStyle() {
    this.isHovered = true
    this.el.nativeElement.style.backgroundColor=this.highlight
  }

  @HostListener('mouseleave') 
  public removeStyle() {
    this.isHovered = false
    this.el.nativeElement.style.backgroundColor=''
  }

  @HostBinding('class.bordered-panel')
  public isHovered:boolean = false
}
