import { Injectable } from '@angular/core';
import {
  Router, Resolve,
  RouterStateSnapshot,
  ActivatedRouteSnapshot
} from '@angular/router';
import { Observable, of } from 'rxjs';
import { Movie } from '../models/movie';
import { MoviesService } from '../services/movies.service';

@Injectable({
  providedIn: 'root'
})
export class MovieDataResolver implements Resolve<Movie> {
  
  constructor(private movieSvc: MoviesService){

  }

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Movie> {
    let id = route.params['id']
    return this.movieSvc.getMovieById(id);
  }
}
