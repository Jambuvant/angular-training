import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable, throwError } from 'rxjs';
import { Movie } from '../models/movie';
import { environment } from "../../environments/environment.prod";
import { retry, catchError } from 'rxjs/operators';
import { TokenStorageService } from '../auth/services/token-storage.service';

@Injectable({
  providedIn: 'root'
})
export class MoviesService {

  constructor(private http: HttpClient, private tokenSvc: TokenStorageService) { }

  getMovies(page:number=0, count:number=10): Observable<Movie[]> {
    let url = `${environment.MOVIE_API_URL}?page=${page}&count=${count}`

    return this.http
    .get<Movie[]>(url)
    .pipe(retry(1))
  }

  getMovieById(id:number): Observable<Movie> {


    let url = `${environment.MOVIE_API_URL}/${id}`

    return this.http
    .get<Movie>(url)
    .pipe(retry(1))
  }
}
