import { Component } from '@angular/core';
import { AuthService } from './auth/services/auth.service';
import { TokenStorageService } from './auth/services/token-storage.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'netstar-client';

  isLoggedIn: boolean = false
  user: any

  constructor(private authSvc: AuthService, 
    private tokenSvc: TokenStorageService,
  private router: Router) {
    this.authSvc.loginUpdate.subscribe({
      next: (data: boolean) => {
        this.isLoggedIn = data,
        this.user = this.tokenSvc.getUser()
      }
    })
  }

  ngOnInit(): void {
    if (this.tokenSvc.getToken() != null) {
      this.user = this.tokenSvc.getUser()
      this.isLoggedIn = true
    }
  }

  logout() {
    this.authSvc.logout()
    this.router.navigateByUrl('/auth/login')
  }
}
