import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';

import { ConfirmGuard } from '../guards/confirm.guard';


const routes: Routes = [
  {
    path: 'login',  // auth/login
    component: LoginComponent
  },
  {
    path: 'register',  // auth/register
    component: RegisterComponent,
    canDeactivate:[ConfirmGuard]  // will ask confirm before leaving
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
