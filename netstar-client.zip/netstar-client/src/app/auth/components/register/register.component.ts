import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  form:FormGroup = new FormGroup({
    email: new FormControl('', Validators.compose([Validators.required, Validators.email])),
    fullname: new FormControl('', Validators.compose([Validators.required, Validators.minLength(3)])),
    password: new FormControl('', Validators.compose([Validators.required, Validators.minLength(8)])),
    phoneNumber: new FormControl('', Validators.required)
  })

  isRegisterSuccess: boolean=false
  emailExists: boolean=false

  constructor(private authService: AuthService) { }

  ngOnInit(): void {
  }

  public get Email(): FormControl {
    return this.form.get('email') as FormControl;
  }

  public get Password(): FormControl {
    return this.form.get('password') as FormControl;
  }

  public get Fullname(): FormControl {

    return this.form.get('fullname') as FormControl;
  }

  public get PhoneNumber(): FormControl {
    return this.form.get('phoneNumber') as FormControl;
  }

  signup() {
    if(this.form.valid) {
      console.log("form value", this.form.value)
      // send this data to backend api to add user
      this.authService
      .addUser(this.form.value)
      .subscribe({
        next: (data) => {
          this.isRegisterSuccess = true
          // alert("Successfully registerd")
        },
        error: (err) => {
          if(err.status == 409) {
            this.emailExists=true
          }
          this.isRegisterSuccess = false
          console.log(err)
        }
      })
    } else {
      alert('Failed, invalid data input')
    }
  }
}