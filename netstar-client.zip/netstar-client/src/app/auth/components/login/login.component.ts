import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { TokenStorageService } from '../../services/token-storage.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  credential: any = {
    email: '',
    password: '',
    rememberMe: false
  }
  constructor(private authService: AuthService, private router: Router, private tokenSvc: TokenStorageService) { }

  ngOnInit(): void {
  }

  login(form: NgForm) {
    if (form.valid) {
      this.authService
      .verifyUser(this.credential)
      .subscribe({
        next: (data) => {
          // successfully logged in 
          // redirect to home page
          this.tokenSvc.saveToken(data.token)
          this.tokenSvc.saveUser(data)
        
          // emitting the data
          this.authService.loginUpdate.emit(true)
          this.router.navigateByUrl('/')
        },
        error: (err)=> {
          console.log(err)
        }
      })
      console.log(this.credential)
    } else {
      console.log("invalid form data")
    }
  }

}
