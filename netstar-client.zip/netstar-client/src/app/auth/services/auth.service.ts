import { Injectable, EventEmitter, Output } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

import { environment } from "../../../environments/environment.prod";
import { TokenStorageService } from './token-storage.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  httpOptions = {
    headers: new HttpHeaders({
      'content-type': 'application/json'
    })
  }

  @Output() loginUpdate: EventEmitter<boolean> = new EventEmitter<boolean>();

  // HttpClient is Injected
  constructor(private http:HttpClient, private tokenSvc: TokenStorageService) { }

  public get LoginUpdate(): EventEmitter<boolean> {
    return this.loginUpdate
  }

  addUser(user: any): Observable<any> {
    let url = `${environment.AUTH_API_URL}/register`;

    return this.http.post<any>(url, user, this.httpOptions)
      .pipe(retry(1))
      // .pipe(retry(1), catchError(this.errorHandler))
  }

  verifyUser(credential: any): Observable<any> {
    let url = `${environment.AUTH_API_URL}/login`;

    return this.http.post<any>(url, credential, this.httpOptions)
    .pipe(retry(1))
  }

  logout() {
    this.tokenSvc.clearAll()
    this.LoginUpdate.emit(false)
  }

  private errorHandler(error: any) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(() => {
      return errorMessage;
    });
  }
}
