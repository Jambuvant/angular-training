import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpHeaders
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { TokenStorageService } from '../auth/services/token-storage.service';

@Injectable()
export class AuthTokenInterceptor implements HttpInterceptor {

  constructor(private tokenSvc: TokenStorageService) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (request.url.indexOf("/api/movies") > 0) {
      let token = this.tokenSvc.getToken()
      let req = request.clone({
        headers: new HttpHeaders({
          'Authorization': `Bearer ${token}`
        })
      });
      // modified request
      return next.handle(req);
    }
    // original request
    return next.handle(request);

  }
}
